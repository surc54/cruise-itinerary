export default {
    database: {
        host: "34.74.17.179",
        user: "web.server",
        password: "dT25lax4pIqv",
        database: "cruise_itinerary",
    },
    APIKey: "&key=AIzaSyC2WPf11JIBDQ41-mAoiOJoT9MJ4w7jYD8"
};

